﻿namespace Bursify.Entities
{
    public interface IEntityBase
    {
        int ID { get; }
    }
}
