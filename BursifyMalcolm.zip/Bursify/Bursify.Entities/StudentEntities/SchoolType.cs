﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bursify.Entities.StudentEntities
{
    public enum SchoolType
    {
        HIGH_SCHOOL = 1,
        UNIVERSITY = 2,
        COLLEGE = 3
    }
}
